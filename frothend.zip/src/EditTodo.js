import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';

const EditTodo = () => {
  const { id } = useParams(); // get todo_id from URL
  const navigate = useNavigate();

  const [task, setTask] = useState('');
  const [description, setDescription] = useState('');

  useEffect(() => {
    fetchTodoData();
  }, []);

  const fetchTodoData = async () => {
    try {
      const res = await axios.get(`http://localhost:3001/to_do/get_todo/${id}`);
      if (res.data.status) {
        const todo = res.data.todo;
        setTask(todo.task);
        setDescription(todo.description);
      } else {
        alert("Todo not found");
        navigate('/');
      }
    } catch (err) {
      console.error("Fetch todo error:", err.message);
    }
  };

  const handleUpdate = async (e) => {
    e.preventDefault();

    if (!task || !description) {
      alert("Please fill in all fields");
      return;
    }

    try {
      const res = await axios.post('http://localhost:3001/to_do/edit_todo', {
        todo_id: id,
        task,
        description
      });

      if (res.data.status) {
        alert("Todo updated successfully!");
        navigate('/');
      }
    } catch (err) {
      console.error("Edit todo error:", err.message);
    }
  };

  return (
    <div style={{ padding: '20px', maxWidth: '500px', margin: 'auto' }}>
      <h2>Edit Todo</h2>
      <form onSubmit={handleUpdate}>
        <div style={{ marginBottom: '10px' }}>
          <label>Task:</label><br />
          <input
            type="text"
            value={task}
            onChange={(e) => setTask(e.target.value)}
            style={{ width: '100%', padding: '8px' }}
            required
          />
        </div>

        <div style={{ marginBottom: '10px' }}>
          <label>Description:</label><br />
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
            style={{ width: '100%', padding: '8px' }}
            required
          />
        </div>

        <button type="submit" style={{ padding: '10px 20px' }}>
          Update Todo
        </button>
      </form>
    </div>
  );
};

export default EditTodo;

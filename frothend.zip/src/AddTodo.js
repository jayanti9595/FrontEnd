import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const AddTodo = () => {
  const [task, setTask] = useState('');
  const [description, setDescription] = useState('');

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!task || !description) {
      alert("Please fill in all fields");
      return;
    }

    try {
      const res = await axios.post('http://localhost:3001/to_do/add_todo', {
        task,
        description
      });

      if (res.data.status) {
        alert("Todo added successfully!");
        navigate('/');
      }
    } catch (err) {
      console.error("Add todo error:", err.message);
    }
  };

  return (
    <div style={{ padding: '20px', maxWidth: '500px', margin: 'auto' }}>
      <h2>Add New Todo</h2>
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: '10px' }}>
          <label>Task:</label><br />
          <input
            type="text"
            value={task}
            onChange={(e) => setTask(e.target.value)}
            style={{ width: '100%', padding: '8px' }}
            required
          />
        </div>

        <div style={{ marginBottom: '10px' }}>
          <label>Description:</label><br />
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
            style={{ width: '100%', padding: '8px' }}
            required
          />
        </div>

        <button type="submit" style={{ padding: '10px 20px' }}>
          Add Todo
        </button>
      </form>
    </div>
  );
};

export default AddTodo;

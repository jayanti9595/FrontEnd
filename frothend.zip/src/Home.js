import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Home = () => {
  const [todoList, setTodoList] = useState([]);
  const [filterStatus, setFilterStatus] = useState('all');
  const navigate = useNavigate();

  useEffect(() => {
    fetchTodos();
  }, []);

  const fetchTodos = async () => {
    try {
      const response = await axios.get('http://localhost:3001/to_do/get_data');
      if (response.data.status) {
        setTodoList(response.data.todo_data);
      }
    } catch (error) {
      console.error('Error fetching todos:', error.message);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this todo?")) return;

    try {
      const res = await axios.post('http://localhost:3001/to_do/delete_todo', {
        data: { todo_id: id },
      });

      if (res.data.status) {
        alert(res.data.msg);
        fetchTodos();
      }
    } catch (err) {
      console.error('Delete error:', err.message);
    }
  };

  const handleStatusUpdate = async (id, currentStatus) => {
    try {
      const newStatus = currentStatus === 'completed' ? 'pending' : 'completed';
      const res = await axios.post('http://localhost:3001/to_do/update_todo_status', {
        todo_id: id,
        status: newStatus,
      });

      if (res.data.status) {
        alert(`Status updated to ${newStatus}`);
        fetchTodos();
      }
    } catch (err) {
      console.error('Status update error:', err.message);
    }
  };

  const filteredTodos = todoList.filter(todo => {
    if (filterStatus === 'all') return true;
    return todo.status === filterStatus;
  });

  return (
    <div style={{ padding: '20px' }}>
      <h2>Todo List</h2>
      
      <div style={{ marginBottom: '20px', display: 'flex', justifyContent: 'space-between' }}>
        <div>
          <button 
            onClick={() => navigate('/add-todo')}
            style={{
              padding: '8px 16px',
              background: '#4CAF50',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            Add New Todo
          </button>
        </div>
        
        <div>
          <label htmlFor="status-filter" style={{ marginRight: '10px' }}>Filter by status: </label>
          <select
            id="status-filter"
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            style={{ padding: '8px', borderRadius: '4px' }}
          >
            <option value="all">All</option>
            <option value="pending">Pending</option>
            <option value="completed">Completed</option>
          </select>
        </div>
      </div>
      
      <table border="1" width="100%" cellPadding="10" style={{ borderCollapse: 'collapse' }}>
        <thead style={{ background: '#f4f4f4' }}>
          <tr>
            <th>S No.</th>
            <th>Task</th>
            <th>Description</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredTodos.length === 0 ? (
            <tr>
              <td colSpan="5">No todo data found</td>
            </tr>
          ) : (
            filteredTodos.map((todo, index) => (
              <tr key={todo._id}>
                <td>{index + 1}</td>
                <td>{todo.task}</td>
                <td>{todo.description}</td>
                <td>
                  <span style={{
                    color: todo.status === 'completed' ? 'green' : 'orange',
                    fontWeight: 'bold'
                  }}>
                    {todo.status}
                  </span>
                </td>
                <td>
                  <button 
                    onClick={() => navigate(`/edit-todo/${todo._id}`)} 
                    style={{ 
                      marginRight: '8px',
                      padding: '6px 12px',
                      background: '#2196F3',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer'
                    }}
                  >
                     Edit
                  </button>
                  <button 
                    onClick={() => handleDelete(todo._id)} 
                    style={{ 
                      marginRight: '8px', 
                      padding: '6px 12px',
                      background: '#f44336',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer'
                    }}
                  >
                     Delete
                  </button>
                  <button 
                    onClick={() => handleStatusUpdate(todo._id, todo.status)} 
                    style={{ 
                      padding: '6px 12px',
                      background: todo.status === 'completed' ? '#FF9800' : '#4CAF50',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer'
                    }}
                  >
                    {todo.status === 'completed' ? ' Mark Pending' : 'Mark Completed'}
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default Home;
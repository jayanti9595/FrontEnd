import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import Home from './Home';
import AddTodo from './AddTodo';
import EditTodo from './EditTodo';

function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/add-todo" element={<AddTodo />} />
          <Route path="/edit-todo/:id" element={<EditTodo />} />
          {/* 
          <Route path="/edit/:id" element={<EditTodo />} />
          <Route path="/todos" element={<TodoList />} /> */}
        </Routes>
      </Router>
    </div>
  );
}

export default App;
